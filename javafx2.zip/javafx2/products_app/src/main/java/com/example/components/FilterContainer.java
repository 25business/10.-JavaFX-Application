package com.example.components;

import com.example.utils.ProductsParser;
import javafx.geometry.Insets;
import javafx.scene.control.Accordion;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TitledPane;
import javafx.scene.layout.VBox;

import java.util.ArrayList;


public class FilterContainer extends VBox {

    private ArrayList<CheckBox> cbListSuppliers;

    public FilterContainer() {
        super();
        Accordion filters = new Accordion();
        VBox supplierCheckboxes = new VBox();
        TitledPane supplierPane = new TitledPane("Supplier", supplierCheckboxes);
        ArrayList<String> suppliers = ProductsParser.suppliers();
        cbListSuppliers = new ArrayList<>();
        suppliers.forEach( supplier -> cbListSuppliers.add(new CheckBox(supplier)) );
        cbListSuppliers.forEach( checkBox -> supplierCheckboxes.getChildren().add(checkBox));

        TitledPane pricePane = new TitledPane();
        pricePane.setText("Price");

        Button buttonFilter = new Button("Filter");

        filters.getPanes().addAll(supplierPane, pricePane);
        this.getChildren().addAll(filters, buttonFilter);
        this.setPadding(new Insets(10));
        this.setSpacing(10);
    }
}
