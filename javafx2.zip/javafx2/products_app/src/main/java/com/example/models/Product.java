package com.example.models;

import java.io.Serializable;

public class Product implements Serializable {
    private String ProductId;
    private String Category;
    private String MainCategory;
    private String TaxTarifCode;
    private String SupplierName;
    private double WeightMeasure;
    private String WeightUnit;
    private String Description;
    private String Name;
    private String ProductPicUrl;
    private String Status;
    private int Quantity;
    private String UoM;
    private String CurrencyCode;
    private double Price;
    private double Width;
    private double Depth;
    private double Height;
    private String DimUnit;

    public String getProductId() {
        return ProductId;
    }

    public void setProductId(String productId) {
        ProductId = productId;
    }

    public String getCategory() {
        return Category;
    }

    public void setCategory(String category) {
        Category = category;
    }

    public String getMainCategory() {
        return MainCategory;
    }

    public void setMainCategory(String mainCategory) {
        MainCategory = mainCategory;
    }

    public String getTaxTarifCode() {
        return TaxTarifCode;
    }

    public void setTaxTarifCode(String taxTarifCode) {
        TaxTarifCode = taxTarifCode;
    }

    public String getSupplierName() {
        return SupplierName;
    }

    public void setSupplierName(String supplierName) {
        SupplierName = supplierName;
    }

    public double getWeightMeasure() {
        return WeightMeasure;
    }

    public void setWeightMeasure(double weightMeasure) {
        WeightMeasure = weightMeasure;
    }

    public String getWeightUnit() {
        return WeightUnit;
    }

    public void setWeightUnit(String weightUnit) {
        WeightUnit = weightUnit;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getProductPicUrl() {
        return ProductPicUrl;
    }

    public void setProductPicUrl(String productPicUrl) {
        ProductPicUrl = productPicUrl;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public int getQuantity() {
        return Quantity;
    }

    public void setQuantity(int quantity) {
        Quantity = quantity;
    }

    public String getUoM() {
        return UoM;
    }

    public void setUoM(String uoM) {
        UoM = uoM;
    }

    public String getCurrencyCode() {
        return CurrencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        CurrencyCode = currencyCode;
    }

    public double getPrice() {
        return Price;
    }

    public void setPrice(double price) {
        Price = price;
    }

    public double getWidth() {
        return Width;
    }

    public void setWidth(double width) {
        Width = width;
    }

    public double getDepth() {
        return Depth;
    }

    public void setDepth(double depth) {
        Depth = depth;
    }

    public double getHeight() {
        return Height;
    }

    public void setHeight(double height) {
        Height = height;
    }

    public String getDimUnit() {
        return DimUnit;
    }

    public void setDimUnit(String dimUnit) {
        DimUnit = dimUnit;
    }
}
