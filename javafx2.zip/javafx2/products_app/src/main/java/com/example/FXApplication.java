package com.example;

import com.example.components.FilterContainer;
import com.example.components.ProductsGrid;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class FXApplication extends Application {
    public static ScrollPane productsGridScroll = new ScrollPane();
    @Override
    public void start(Stage stage) throws Exception {
        stage.setTitle("Products Search");
        stage.setWidth(800);
        stage.setHeight(600);

        HBox.setHgrow(productsGridScroll, Priority.ALWAYS);

        HBox main_layout = new HBox();
        FilterContainer filterContainer = new FilterContainer();
        ProductsGrid productsGrid = new ProductsGrid();
        productsGridScroll.setContent(productsGrid);
        main_layout.getChildren().addAll(filterContainer, productsGrid, productsGridScroll);
        main_layout.setFillHeight(true);

        Scene scene = new Scene(main_layout);
        stage.setScene(scene);
        stage.show();
    }
    public static void main(String[] args) {
        FXApplication.launch(args);
    }
}