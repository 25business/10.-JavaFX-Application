package com.example.components;

import com.example.FXApplication;
import com.example.models.Product;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

import java.io.File;
import java.io.FileInputStream;

public class ProductDetails extends VBox {

    public ProductDetails(Product product) {
        HBox backButtonContainer = new HBox();
        Button backButton = new Button("Back");

        backButton.setOnAction( actionEvent -> FXApplication.productsGridScroll.setContent(new ProductsGrid()));

        backButtonContainer.getChildren().add(backButton);
        this.getChildren().add(backButtonContainer);

        try {
            FileInputStream imgStream = new FileInputStream(
                    new File(System.getenv("JAVA_RESOURCES") + "/products/"
                            + product.getProductPicUrl() )
            );
            Image productImage = new Image(imgStream);
            ImageView imageView = new ImageView(productImage);
            imageView.setFitWidth(200);
            imageView.setFitHeight(200);
            imageView.setPreserveRatio(true);
            this.getChildren().add(imageView);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        Label productTitle = new Label(product.getName());
        productTitle.setFont(new Font("Arial", 24));
        Label productId = new Label(product.getProductId());


        this.getChildren().add(productTitle);
        this.getChildren().add(productId);
        this.setAlignment(Pos.TOP_CENTER);
        this.setPadding(new Insets(20));
        this.setStyle("-fx-background-color: white");
        this.setSpacing(8);
        this.setPrefWidth(FXApplication.productsGridScroll.widthProperty().getValue());
        this.setPrefHeight(FXApplication.productsGridScroll.heightProperty().getValue());
    }
}
