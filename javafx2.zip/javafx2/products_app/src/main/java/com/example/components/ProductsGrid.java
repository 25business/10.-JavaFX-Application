package com.example.components;

import com.example.models.Product;
import com.example.utils.ProductsParser;
import javafx.scene.layout.TilePane;

import java.util.List;

public class ProductsGrid extends TilePane {
    private int MAX_COLUMNS = 3;

    public ProductsGrid() {
        super();
        this.setHgap(10);
        this.setVgap(10);
        List<Product> products = ProductsParser.range(0,24);
        this.setPrefColumns(this.MAX_COLUMNS);
        for(var product : products) {
            this.getChildren().add(new ProductCell(product));
        }
    }
}
