package com.example.components;

import com.example.FXApplication;
import com.example.models.Product;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;

import java.io.File;
import java.io.FileInputStream;

public class ProductCell extends VBox {

    public ProductCell(Product product) {
        super();
        this.setAlignment(Pos.TOP_CENTER);
        this.setPrefWidth(200);
        this.setSpacing(10);
        this.setStyle("""
              -fx-background-color: white;
              -fx-border-color: black;
               -fx-border-style: solid;
               -fx-border-width: 1;
              """);
        try {
            FileInputStream imgStream = new FileInputStream(
                    new File(System.getenv("JAVA_RESOURCES") + "/products/"
                            + product.getProductPicUrl() )
            );
            Image productImage = new Image(imgStream);
            ImageView imageView = new ImageView(productImage);
            imageView.setFitWidth(100);
            imageView.setFitHeight(100);
            imageView.setPreserveRatio(true);
            this.getChildren().add(imageView);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        Label productName = new Label(product.getName());
        productName.setWrapText(true);
        productName.setAlignment(Pos.CENTER);
        this.getChildren().add(productName);

        Button detailsButton = new Button("Details");
        detailsButton.setUserData(product);
        detailsButton.setStyle("""
                -fx-text-fill: white;
                -fx-background-color: #670d6e;
                -fx-padding-top: 10;
                -fx-padding-bottom: 10;
                -fx-padding-left: 20;
                -fx-padding-right: 20;
                """);

        detailsButton.setOnAction( actionEvent -> {
            Product buttonProduct = (Product)detailsButton.getUserData();
            ProductDetails productDetails = new ProductDetails(buttonProduct);
            FXApplication.productsGridScroll.setContent(productDetails);
        });

        this.getChildren().add(detailsButton);
    }
}
