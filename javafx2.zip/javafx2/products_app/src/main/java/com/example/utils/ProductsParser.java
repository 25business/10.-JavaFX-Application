package com.example.utils;

import com.example.models.Product;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ProductsParser {

    public static ArrayList<Product> all() {
        ArrayList<Product> products = new ArrayList<>();
        try {
            Gson gson = new Gson();
            String content = Files.readString(Path.of(System.getenv("JAVA_RESOURCES"),"products/products.json"));
            products = gson.fromJson(content, new TypeToken<ArrayList<Product>>(){}.getType());

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return products;
    }
    public static ArrayList<Product> range(int start_index) {
        ArrayList<Product> products = all();
        return (ArrayList<Product>) products.subList(start_index, products.size()-1);
    }
    public static List<Product> range(int start_index, int end_index) {
        ArrayList<Product> products = all();
        return products.subList(start_index, end_index);
    }

    public static ArrayList<String> suppliers() {
        ArrayList<Product> products = all();
        ArrayList<String> suppliers = new ArrayList<>();
        for(var product : products) {
            suppliers.add(product.getSupplierName());
        }
        ArrayList<String> filtered_suppliers = new ArrayList<>();
        for(int i = 0; i < suppliers.size(); i++) {
            boolean isFound = false;
            for(int j = 0; j < filtered_suppliers.size(); j++) {
                if(suppliers.get(i).equals(filtered_suppliers.get(j))) {
                    isFound = true; break;
                }
            }
            if(!isFound) { filtered_suppliers.add(suppliers.get(i)); }
        }

        return filtered_suppliers;
    }
}
